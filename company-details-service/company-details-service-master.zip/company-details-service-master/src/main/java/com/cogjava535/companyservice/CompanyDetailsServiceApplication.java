package com.cogjava535.companyservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CompanyDetailsServiceApplication {

	public static void main(String[] args) {
		System.out.println("Hello World!");
		SpringApplication.run(CompanyDetailsServiceApplication.class, args);
	}

}
